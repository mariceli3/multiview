
General examples
----------------

General-purpose and introductory examples for the multiview.