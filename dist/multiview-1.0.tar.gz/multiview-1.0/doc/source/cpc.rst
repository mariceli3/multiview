  
.. toctree::
   :maxdepth: 2
   :caption: Contents:

CPC
===
Multiview Common Principal Components 
-------------------------------------

   
.. automodule:: multiview.cpcmv

.. autoclass:: MVCPC

  .. automethod:: fit
  .. automethod:: fit_transform
