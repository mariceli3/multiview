  
.. toctree::
   :maxdepth: 2
   :caption: Contents:

MV-SC
======
Multiview Spectral Clustering 
-----------------------------

   
.. automodule:: multiview.mvsc

.. autoclass:: MVSC

  .. automethod:: fit
  .. automethod:: fit_transform
